let a=3,b=20;
var c=a+b;
console.log("Sum of a+b is:",c);
document.write("Sum of a+b is:",c);
